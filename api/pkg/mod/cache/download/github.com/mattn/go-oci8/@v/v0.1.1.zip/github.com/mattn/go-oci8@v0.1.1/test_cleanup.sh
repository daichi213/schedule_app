rm -rf /usr/local/go1.15.x
rm -rf /usr/local/go1.14.x
rm -rf /usr/local/go1.13.x
rm -rf /usr/local/go1.12.x
rm -rf /usr/local/go1.11.x
rm -rf /usr/local/go1.10.x
rm -rf /usr/local/go1.9.x
rm -rf /usr/local/pkg_config

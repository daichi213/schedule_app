package icmd

// CmdOp is an operation which modified a Cmd structure used to execute commands
type CmdOp func(*Cmd)

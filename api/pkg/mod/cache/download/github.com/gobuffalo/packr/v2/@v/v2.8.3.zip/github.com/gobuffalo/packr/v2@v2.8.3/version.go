package packr

// Version of Packr
const Version = "v2.8.3"

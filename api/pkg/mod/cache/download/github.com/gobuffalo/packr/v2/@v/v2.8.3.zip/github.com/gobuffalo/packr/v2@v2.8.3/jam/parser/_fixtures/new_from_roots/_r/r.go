package q

import "github.com/gobuffalo/packr/v2"

func init() {
	packr.New("bob", "dylan")
}

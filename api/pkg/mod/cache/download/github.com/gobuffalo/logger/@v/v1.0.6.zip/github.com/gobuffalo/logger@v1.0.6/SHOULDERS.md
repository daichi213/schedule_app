# github.com/gobuffalo/logger Stands on the Shoulders of Giants

github.com/gobuffalo/logger does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/konsorten/go-windows-terminal-sequences](https://godoc.org/github.com/konsorten/go-windows-terminal-sequences)

* [github.com/rogpeppe/go-internal](https://godoc.org/github.com/rogpeppe/go-internal)

* [github.com/sirupsen/logrus](https://godoc.org/github.com/sirupsen/logrus)

* [golang.org/x/term](https://godoc.org/golang.org/x/term)

* [golang.org/x/sys](https://godoc.org/golang.org/x/sys)

// +build !windows

// Copyright 2017, 2020 The Godror Authors
//
//
// SPDX-License-Identifier: UPL-1.0 OR Apache-2.0

package godror

// #cgo LDFLAGS: -ldl -lpthread
import "C"

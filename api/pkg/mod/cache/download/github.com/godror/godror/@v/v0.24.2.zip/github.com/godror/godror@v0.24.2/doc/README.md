# Go DRiver for ORacle Documentation

This `godror/doc` directory contains the user guide source files.
Visit https://godror.github.io/godror/doc/contents.html to view the User Guide.  The API Documentation is at https://pkg.go.dev/github.com/godror/godror?tab=doc.

This directory contains the file dpi.c which can be used to embed ODPI-C
within your project without having to manage the individual files that make up
the library. The files can also be compiled independently if that is preferred.

/*Package x is a namespace for experimental packages. Packages under x have looser
compatibility requirements. Packages in this namespace may contain backwards
incompatible changes within the same major version.
*/
package x // import "gotest.tools/v3/x"

/*Package gotesttools is a collection of packages to augment `testing` and
support common patterns.
*/
package gotesttools // import "gotest.tools/v3"
